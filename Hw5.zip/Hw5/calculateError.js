function getDecimal(){
	
    //get the binary string
    let x = document.getElementById("myBinary").value;
    
    let y = isBinary(x);//Alert
    
    if (!y){ //Alertx2
        document.getElementById("solution").innerHTML="Not binary";
    }else{
        let decimal = 0, power = x.length-1;
        //Calculate decimal here
        for (let i=0; i<x.length; i++){ //Alert
            let c = x.charAt(i);
            //convert character to int
            c = parseInt(c);
            
            //Sum those that have bits equal to 1
            if (c == 1){
                decimal = decimal + Math.pow(2, power)
            }

            //reduce power by 1 each iteration
            power--;
        }
        
        //Print decimal to h2 tag
        document.getElementById("solution").innerHTML = ""+decimal; //Alert
    }
}

/**
 * Returns true if bNumber is a binary and false otherwise
 */
function isBinary(bNumber){ 
    for (let i=0; i<bNumber.length; i++){
        let c = bNumber.charAt(i); //Alert
        //Check if a charcater is 1 or 0
        if (c != '0' && c != '1'){
            return false;
        }
    }
    return true;
}